module.exports = {
    mongoUrl: 'mongodb+srv://admin:admin%40123@cluster0.xkbg1nx.mongodb.net/evenisgroup?retryWrites=true&w=majority',
    jwt_ExpiresIn: "30d",
    jwt_secret_key: "Secret_Key"
}

// Replace %40 with @ in password, i.e password is - admin@123
